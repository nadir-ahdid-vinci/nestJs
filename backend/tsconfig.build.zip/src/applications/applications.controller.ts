// applications/applications.controller.ts (Contrôleur Applications)
import { Controller, Get, Post, Body, Param, ParseIntPipe, Patch, Req } from '@nestjs/common';
import { CreateApplicationDto } from './dto/create-application.dto';
import { ApplicationsService } from './applications.service';
import { Application } from './entities/application.entity';
import { UsersService } from '../users/users.service';
import { ApplicationLogService } from './applications-log.service';
import { ApplicationLog } from './entities/application-log.entity';
import { UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Role } from 'src/auth/roles.decorator';

@Controller('applications')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ApplicationsController {
  constructor(
    private appService: ApplicationsService,
    private usersService: UsersService,
    private logService: ApplicationLogService,
  ) {}

  @Get('hunter')
  @Role('HUNTER')
  async findAllForHunters(): Promise<Application[]> {
    return this.appService.findAllForHunters();
  }

  @Get('dev/:id')
  @Role('HUNTER_DEV')
  async findAllForDevelopers(@Param('id', ParseIntPipe) id: number): Promise<Application[]> {
    const user = await this.usersService.findOneWithApplications(id);
    return user ? user.applications : [];
  }

  @Get(':id/logs')
  @Role('HUNTER_ADMIN')
  async getLogs(@Param('id', ParseIntPipe) id: number): Promise<ApplicationLog[]> {
    return this.logService.getLogsByApplication(id);
  }

  @Get()
  @Role('HUNTER_ADMIN')
  async findAll(): Promise<Application[]> {
    return await this.appService.findAll();
  }

  @Get(':id')
  @Role('HUNTER')
  findOne(@Param('id', ParseIntPipe) id: number): Promise<Application> {
    return this.appService.findOne(id);
  }

  @Post()
  @Role('HUNTER_ADMIN')
  create(@Body() createApplicationDto: CreateApplicationDto, @Req() req): Promise<Application> {
    console.log(req.user);
    return this.appService.create(createApplicationDto, req.user);
  }

  @Patch(':id')
  @Role('HUNTER_ADMIN')
  update(@Param('id', ParseIntPipe) id: number, @Body() updateApplicationDto: CreateApplicationDto, @Req() req): Promise<Application> {
    return this.appService.update(id, updateApplicationDto, req.user);
  }
}